package io.seata.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockXAApplication {

    public static void main(String[] args) {
        SpringApplication.run(StockXAApplication.class, args);
    }

}
